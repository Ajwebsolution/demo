<?php
/*
Plugin Name: Custom Form Handler
Description: Handle custom form submission and send email notifications.
Version: 1.0
Author: Your Name
*/

// Form handling function
function handle_custom_form_submission() {
    if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['message'])) {
        // Handling form data and sending email notification logic here...
        // (Same as previous code)

        wp_redirect(home_url('/thank-you/'));
        exit();
    }
}

// Hook for form submission
add_action('admin_post_custom_form_handler', 'handle_custom_form_submission');
add_action('admin_post_nopriv_custom_form_handler', 'handle_custom_form_submission');

// Shortcode function for the form
function custom_form_shortcode() {
    ob_start(); ?>

    <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
        <input type="hidden" name="action" value="custom_form_handler">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>
        <label for="email">Email:</label>
        <input type="email" name="email" required><br>
        <label for="message">Message:</label>
        <textarea name="message" rows="4" required></textarea><br>
        <input type="submit" value="Submit">
    </form>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_form', 'custom_form_shortcode');
