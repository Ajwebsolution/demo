<?php
/*
Plugin Name: User Role Price Discount
Description: Apply different price discounts based on user roles for all products and display the discounted price.
Version: 1.0
Author: Your Name
*/

// Add settings page to set role-based discounts
function role_based_discount_settings() {
    add_menu_page(
        'Role-based Discounts',
        'Role Discounts',
        'manage_options',
        'role_discount_settings',
        'role_discount_settings_page'
    );
}
add_action('admin_menu', 'role_based_discount_settings');

// Display settings page content
function role_discount_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $user_roles = wp_roles()->roles;
    $role_discounts = get_option('role_based_discounts', []);

    if (isset($_POST['submit'])) {
        $submitted_discounts = $_POST['role_discount'] ?? [];

        foreach ($user_roles as $role => $details) {
            if (isset($submitted_discounts[$role])) {
                $discount_percentage = absint($submitted_discounts[$role]);
                $role_discounts[$role] = $discount_percentage;
            }
        }

        update_option('role_based_discounts', $role_discounts);
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    ?>
    <div class="wrap">
        <h1>Role-based Discounts</h1>
        <form method="post">
            <?php foreach ($user_roles as $role => $details) { ?>
                <h2><?php echo esc_html($details['name']); ?> Discount</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="role_discount_<?php echo esc_attr($role); ?>">Discount (%) for <?php echo esc_html($details['name']); ?></label></th>
                        <td><input type="number" name="role_discount[<?php echo esc_attr($role); ?>]" id="role_discount_<?php echo esc_attr($role); ?>" value="<?php echo esc_attr($role_discounts[$role] ?? 0); ?>" /></td>
                    </tr>
                </table>
            <?php } ?>
            <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
        </form>
    </div>
    <?php
}

// Apply role-based discounts for all products
function apply_role_based_discount($price, $product) {
    $user = wp_get_current_user();

    if (is_user_logged_in() && !empty($user->roles)) {
        $user_role = $user->roles[0];

        $role_discounts = get_option('role_based_discounts', []);

        if (isset($role_discounts[$user_role])) {
            $discount_percentage = $role_discounts[$user_role];
            $discount = $product->get_price() * ($discount_percentage / 100);
            $discounted_price = $product->get_price() - $discount;

            // Return the discounted price instead of the original price
            return wc_price($discounted_price);
        }
    }

    return $price;
}

// Hook into the WooCommerce price display for all products
add_filter('woocommerce_get_price_html', 'apply_role_based_discount', 10, 2);
