// Example JavaScript code for custom functionality
jQuery(document).ready(function($) {
    // Your custom JavaScript/jQuery code goes here

    // Example: Change the background color of an element
    $('.your-element-class').css('background-color', '#f00');

    // Example: Toggle a class on click
    $('.toggle-button').on('click', function() {
        $('.toggle-element').toggleClass('active');
    });

    // Add more custom JavaScript/jQuery code as needed
});
// Display an alert message when the page is loaded
// window.addEventListener('load', function() {
//     alert('Welcome to our website!');
// });
