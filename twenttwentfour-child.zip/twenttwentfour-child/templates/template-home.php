<?php
/*
*Template Name: Home Page
*/

get_header();


?>
	<main role="main">

		<section class="blog-page-area section-padding">
			<div class="container">
				<h2 class="text-center"></h2><br>
				<div class="row">
				<div class="taggbox" style="width:100%;height:100%" data-widget-id="144979" data-tags="false" ></div><script src="https://widget.taggbox.com/embed-lite.min.js" type="text/javascript"></script>		
				</div>
			</div>
		</section>

	</main>

<?php get_footer();