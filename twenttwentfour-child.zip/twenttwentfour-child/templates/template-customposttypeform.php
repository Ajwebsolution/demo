<?php
// Template Name: customposttypeform
get_header();

if (isset($_POST['savepost'])) {
    $post_data = array(
        'post_type' => 'post',
        'post_status' => 'draft', // Set the initial status to draft for admin approval.
        'post_title' => $_POST['ntitle'],
        'post_content' => $_POST['ndes'],
    );

    $post_id = wp_insert_post($post_data);

    if ($post_id) {
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === 0) {
            // Include the necessary file for wp_handle_upload.
            require_once(ABSPATH . 'wp-admin/includes/file.php');

            // Handle the featured image upload.
            $upload_dir = wp_upload_dir();
            $image_data = wp_handle_upload($_FILES['featured_image'], array('test_form' => false));

            if (isset($image_data['url'])) {
                // Set the featured image for the post.
                $attachment = array(
                    'post_mime_type' => $image_data['type'],
                    'post_title' => sanitize_file_name(pathinfo($image_data['file'], PATHINFO_FILENAME)),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                $attach_id = wp_insert_attachment($attachment, $image_data['file'], $post_id);
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                $attach_data = wp_generate_attachment_metadata($attach_id, $image_data['file']);
                wp_update_attachment_metadata($attach_id, $attach_data);
                set_post_thumbnail($post_id, $attach_id);
            } else {
                // Handle the situation when 'url' is not defined in $image_data.
                // You can log an error, display a message, or take appropriate action.
                // For example, you can echo an error message:
                echo 'Error: Featured image URL not found in $image_data.';
            }
        }
    }
}
?>

<div class="container-fluid py-5">
    <h1 class="display-4 text-uppercase text-center mb-5">Add Blog</h1>
    <form method="post" class="formdata" enctype="multipart/form-data">
        <div class="form-group">
            <input type="text" class="form-control p-4" placeholder="Insert post title here" name="ntitle" required>
        </div>
        <div class="form-group">
            <input type="text" class="form-control p-4" name="ndes" placeholder="Insert post description here" required>
        </div>
        <div class="form-group">
            <label for="featured_image">Featured Image:</label>
            <input type="file" name="featured_image" id="featured_image">
        </div>
        <div>
            <button class="btn btn-primary py-3 px-5" name="savepost" type="submit">Save Data</button>
        </div>
    </form>
</div>

<?php
get_footer();
?>