<?php
/*
Template Name: Search Results Template
*/

get_header(); // Include the header of your theme

$submitted = false; // Initialize a variable to track form submission

// Handle form submission
if (isset($_POST['submit'])) {
    global $wpdb;

    // Retrieve and sanitize form data
    $input_country = isset($_POST['input_country']) ? sanitize_text_field($_POST['input_country']) : '';
    $input_city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
    $input_username = isset($_POST['input_username']) ? sanitize_text_field($_POST['input_username']) : '';
    $input_fullname = isset($_POST['input_fullname']) ? sanitize_text_field($_POST['input_fullname']) : '';
    $input_address = isset($_POST['input_address']) ? sanitize_text_field($_POST['input_address']) : '';
    $input_phone = isset($_POST['input_phone']) ? sanitize_text_field($_POST['input_phone']) : '';
    $input_postalcode = isset($_POST['input_postalcode']) ? sanitize_text_field($_POST['input_postalcode']) : '';
    $input_area = isset($_POST['area']) ? sanitize_text_field($_POST['area']) : ''; // Add area field
    $input_visatype = isset($_POST['visatype']) ? sanitize_text_field($_POST['visatype']) : ''; // Add visatype field

    // Table name
    $table_name = $wpdb->prefix . 'country';

    // Example of database insertion (Modify this according to your table structure)
    $wpdb->insert(
        $table_name,
        array(
            'country' => $input_country,
            'city' => $input_city,
            'username' => $input_username,
            'fullname' => $input_fullname,
            'address' => $input_address,
            'phone' => $input_phone,
            'postalcode' => $input_postalcode, // Include postalcode field
            'area' => $input_area,
            'visatype' => $input_visatype,
            // Add more fields as needed
        )
    );

    $submitted = true; // Set submitted to true after successful form submission
   
}
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <h1 style="color: blue; text-align: center;">Search Result</h1>


        <!-- Your existing code for fetching and displaying search results -->

        <!-- Fetch countries from the database -->
        <?php
        global $wpdb;
        $table_name = $wpdb->prefix . 'country';
        $countries = $wpdb->get_col("SELECT DISTINCT country FROM $table_name ORDER BY country");
        ?>

        <!-- Custom Form with Basic Styling -->
        <div class="custom-form" style="max-width: 800px; margin: 0 auto;">

            <form id="custom-search-form" method="post">
                <div class="row">
                    <div class="col">
                        <label for="input_country">Country:</label>
                        <select name="input_country" id="input_country"
                            style="width: 100%; padding: 8px; margin-bottom: 10px;">
                            <option value="">Select Country</option>
                            <?php
                    foreach ($countries as $country) {
                        echo '<option value="' . esc_attr($country) . '">' . esc_html($country) . '</option>';
                    }
                    ?>
                        </select>
                    </div>
                    <div class="col">
                        <label for="input_city">City:</label>
                        <select id="city" name="city" style="width: 100%; padding: 8px; margin-bottom: 10px;">
                            <option value="">Select City</option>
                            <!-- Populate city options dynamically based on selected country -->
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="area">Area:</label>
                        <select id="area" name="area" style="width: 100%; padding: 8px; margin-bottom: 10px;">
                            <option value="">Select Area</option>
                            <!-- Populate area options dynamically based on selected country and city -->
                        </select>
                    </div>
                    <div class="col">
                        <label for="visatype">Visa Type:</label>
                        <select id="visatype" name="visatype" style="width: 100%; padding: 8px; margin-bottom: 10px;">
                            <option value="">Select Visa Type</option>
                            <!-- Options will be dynamically populated via AJAX -->
                        </select>
                    </div>
                </div>

                <!-- Additional custom fields for user information -->
                <div class="row">
                    <div class="col">
                <label for="input_username">Username:</label>
                <input type="text" name="input_username" id="input_username" required
                    style="width: 100%; padding: 8px; margin-bottom: 10px;"> </div>
                    <div class="col">

                <label for="input_fullname">Full Name:</label>
                <input type="text" name="input_fullname" id="input_fullname" required
                    style="width: 100%; padding: 8px; margin-bottom: 10px;">   </div>
                </div>
                <div class="row">
                    <div class="col">
                <label for="input_address">Address:</label>
                <input type="text" name="input_address" id="input_address" required
                    style="width: 100%; padding: 8px; margin-bottom: 10px;"> </div>
                    <div class="col">

                <label for="input_phone">Phone Number:</label>
                <input type="text" name="input_phone" id="input_phone" required
                    style="width: 100%; padding: 8px; margin-bottom: 10px;"> </div>
                </div>

                <label for="input_postalcode">PostalCode:</label>
                <input type="text" name="input_postalcode" id="input_postalcode" required
                    style="width: 100%; padding: 8px; margin-bottom: 10px;"><br>

                <!-- Add more input fields as needed -->

                <input type="submit" name="submit" value="Submit"
                    style=" padding: 10px; background-color: #007bff; color: #fff; border: none; cursor: pointer;">
            </form>
        </div>

        <?php if ($submitted) : ?>
        <!-- Display success message using JavaScript -->
        <div id="success-message" style="display: none; text-align: center; margin-bottom: 20px; color: green;">
            Your form has been submitted successfully!
        </div>

        <script>
        // Show the success message
        document.getElementById('success-message').style.display = 'block';

        // Redirect to the 'Thank You' page after 3 seconds (adjust as needed)
        setTimeout(function() {
            window.location.href = '<?php echo home_url('/thank-you'); ?>';
        }, 3000); // Redirect after 3 seconds
        </script>
        <?php endif; ?>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
        jQuery(document).ready(function($) {
            // Function to fetch and populate cities based on the selected country
            $('#input_country').on('change', function() {
                var country = $(this).val();

                // AJAX request to fetch cities based on the selected country
                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'fetch_cities', // AJAX action to trigger in WordPress
                        country: country
                    },
                    success: function(response) {
                        $('#city').html(response); // Populate cities dropdown
                        $('#area').html(
                            '<option value="">Select Area</option>'
                            ); // Reset areas dropdown
                        $('#visatype').html(
                            '<option value="">Select Visa Type</option>'
                            ); // Reset visatype dropdown
                    },
                    error: function() {
                        alert('Error occurred while fetching cities.');
                    }
                });
            });

            // Function to fetch and populate visatypes based on the selected country and city
            $('#city').on('change', function() {
                var country = $('#input_country').val();
                var city = $(this).val();

                // AJAX request to fetch visatypes based on the selected country and city
                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'fetch_visatypes', // AJAX action to trigger in WordPress
                        country: country,
                        city: city
                    },
                    success: function(response) {
                        $('#visatype').html(response); // Populate visatype dropdown
                    },
                    error: function() {
                        alert('Error occurred while fetching visatypes.');
                    }
                });
            });

            // Function to fetch and populate areas based on the selected country and city
            $('#city').on('change', function() {
                var country = $('#input_country').val();
                var city = $(this).val();

                // AJAX request to fetch areas based on the selected country and city
                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'fetch_areas', // AJAX action to trigger in WordPress
                        country: country,
                        city: city
                    },
                    success: function(response) {
                        $('#area').html(response); // Populate areas dropdown
                    },
                    error: function() {
                        alert('Error occurred while fetching areas.');
                    }
                });
            });
        });
        </script>

    </main><!-- #main -->
</div><!-- #primary -->

<?php get_footer(); // Include the footer of your theme ?>