<?php
/*
 * Template Name: SearchF Template
 */
get_header();
?>

<form action="<?php echo esc_url(home_url('/search-results')); ?>" method="GET">
    <label for="country">Country:</label>
    <select id="country" name="country">
        <option value="">Select Country</option>
        <!-- Populate country options dynamically -->
    </select>

    <label for="city">City:</label>
    <select id="city" name="city">
        <option value="">Select City</option>
        <!-- Populate city options dynamically based on selected country -->
    </select>

    <label for="area">Area:</label>
    <select id="area" name="area">
        <option value="">Select Area</option>
        <!-- Populate area options dynamically based on selected country and city -->
    </select>
    <label for="visatype">Visa Type:</label>
<select id="visatype" name="visatype">
    <option value="">Select Visa Type</option>
    <!-- Options will be dynamically populated via AJAX -->
</select>

    <input type="submit" value="Search">
</form>

<div id="search-results"></div>
<!-- Add this JavaScript code in your WordPress template file or a separate JS file -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    jQuery(document).ready(function($) {
        // Function to fetch and populate cities based on the selected country
        $('#country').on('change', function() {
            var country = $(this).val();

            // AJAX request to fetch cities based on the selected country
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('/wp-admin/admin-ajax.php');
 ?>',
                data: {
                    action: 'fetch_cities', // AJAX action to trigger in WordPress
                    country: country
                },
                success: function(response) {
                    $('#city').html(response); // Populate cities dropdown
                    $('#area').html('<option value="">Select Area</option>'); // Reset areas dropdown
                },
                error: function() {
                    alert('Error occurred while fetching cities.');
                }
            });
        });

        // Function to fetch and populate visatypes based on the selected country and city
$('#city').on('change', function() {
    var country = $('#country').val();
    var city = $(this).val();

    // AJAX request to fetch visatypes based on the selected country and city
    $.ajax({
        type: 'POST',
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        data: {
            action: 'fetch_visatypes', // AJAX action to trigger in WordPress
            country: country,
            city: city
        },
        success: function(response) {
            $('#visatype').html(response); // Populate visatype dropdown
        },
        error: function() {
            alert('Error occurred while fetching visatypes.');
        }
    });
});



        // Function to fetch and populate areas based on the selected country and city
        $('#city').on('change', function() {
            var country = $('#country').val();
            var city = $(this).val();

            // AJAX request to fetch areas based on the selected country and city
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('/wp-admin/admin-ajax.php');
 ?>',
                data: {
                    action: 'fetch_areas', // AJAX action to trigger in WordPress
                    country: country,
                    city: city
                },
                success: function(response) {
                    $('#area').html(response); // Populate areas dropdown
                },
                error: function() {
                    alert('Error occurred while fetching areas.');
                }
            });
        });

        
   // Function to fetch countries and populate the country dropdown on page load
   function fetchCountries() {
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('/wp-admin/admin-ajax.php');
 ?>',
                data: {
                    action: 'fetch_countries' // AJAX action to trigger in WordPress
                },
                success: function(response) {
                    $('#country').html(response); // Populate countries dropdown
                },
                error: function() {
                    alert('Error occurred while fetching countries.');
                }
            });
        }

        // Call fetchCountries function to populate the country dropdown on page load
        fetchCountries();


        // Function to handle form submission and perform search
        $('#search-form').on('submit', function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            // AJAX request to perform the search
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('/wp-admin/admin-ajax.php');
 ?>',
                data: {
                    action: 'perform_search', // AJAX action to trigger in WordPress
                    country: $('#country').val(),
                    city: $('#city').val(),
                    area: $('#area').val()
                },
                success: function(response) {
                    $('#search-results').html(response); // Display search results
                },
                error: function() {
                    alert('Error occurred. Please try again.');
                }
            });
        });
    });
</script>


<?php
get_footer();
?>
