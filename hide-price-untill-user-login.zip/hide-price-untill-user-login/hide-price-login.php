<?php
/*
Plugin Name: Hide Price Until Login
Description: Hide prices until user login and redirect to the My Account page.
Version: 1.0
Author: Your Name
*/

// Function to check if the user is logged in
function hide_price_until_login($price) {
    if (!is_user_logged_in()) {
        $my_account_url = wc_get_page_permalink('myaccount');
        return '<p><a href="' . esc_url($my_account_url) . '">Login to view price</a></p>';
    }
    return $price;
}

// Hook into the WooCommerce price display
add_filter('woocommerce_get_price_html', 'hide_price_until_login');
