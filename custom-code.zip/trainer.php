<?php 
/*
 * Template Name: Trainer Profile Dashboard
 */
get_header();
?>

<section class="news-one">
    <!-- Display Trainer Posts -->
</section>

<form method="post" action="" enctype="multipart/form-data">
    <?php
    // Fetch Trainer Posts for the current logged-in user
    $current_user = wp_get_current_user();
    $trainer_posts = new WP_Query(array(
        'post_type' => 'trainer',
        'posts_per_page' => -1,
        'author' => $current_user->ID, // Filter by the current user ID
    ));

    if ($trainer_posts->have_posts()) :
        while ($trainer_posts->have_posts()) : $trainer_posts->the_post();
    ?>
    <div class="trainer-post" data-post-id="<?php the_ID(); ?>">
        <input type="hidden" name="selected_post_id_<?php the_ID(); ?>" value="<?php the_ID(); ?>" />
        <label for="new_title_<?php the_ID(); ?>">New Title:</label>
        <input type="text" name="new_title_<?php the_ID(); ?>" id="new_title_<?php the_ID(); ?>" value="<?php the_title(); ?>" />
        <label for="new_content_<?php the_ID(); ?>">New Content:</label>
        <textarea name="new_content_<?php the_ID(); ?>" id="new_content_<?php the_ID(); ?>"><?php echo get_the_content(); ?></textarea>
        <label for="new_featured_image_<?php the_ID(); ?>">New Featured Image:</label>
        <input type="file" name="new_featured_image_<?php the_ID(); ?>" id="new_featured_image_<?php the_ID(); ?>" />

        <!-- Displaying City Taxonomy Terms -->
        <?php
        $terms = get_terms(array(
            'taxonomy' => 'city',
            'hide_empty' => false,
        ));

        if (!empty($terms)) {
            echo '<label for="city_<?php the_ID(); ?>">Select City:</label>';
            echo '<select name="city_<?php the_ID(); ?>">';
            foreach ($terms as $term) {
                echo '<option value="' . esc_attr($term->term_id) . '">' . esc_html($term->name) . '</option>';
            }
            echo '</select>';
        }
        ?>

        <label for="new_about_<?php the_ID(); ?>">New About (ACF Field):</label>
        <textarea name="new_about_<?php the_ID(); ?>" id="new_about_<?php the_ID(); ?>"><?php echo get_field('about'); ?></textarea>
    </div>
    <?php endwhile; ?>

    <input type="submit" name="update_posts" value="Update Posts" />

    <?php else :
        echo 'No Trainer posts found for the current user.';
    endif;
    wp_reset_postdata(); // Restore global post data
    ?>
</form>

<?php
if (isset($_POST['update_posts'])) {
    // Loop through each post to update
    $trainer_posts = new WP_Query(array(
        'post_type' => 'trainer',
        'posts_per_page' => -1,
        'author' => $current_user->ID, // Filter by the current user ID
    ));

    if ($trainer_posts->have_posts()) :
        while ($trainer_posts->have_posts()) : $trainer_posts->the_post();
            $selected_post_id = get_the_ID();
            $new_title = sanitize_text_field($_POST['new_title_' . $selected_post_id]);
            $new_content = sanitize_textarea_field($_POST['new_content_' . $selected_post_id]);
            $new_featured_image = $_FILES['new_featured_image_' . $selected_post_id];
            $new_about = sanitize_text_field($_POST['new_about_' . $selected_post_id]); // Replace 'new_about' with your ACF field name

            if ($selected_post_id && $new_title && $new_content) {
                // Update the selected post
                $updated_post = array(
                    'ID'           => $selected_post_id,
                    'post_title'   => $new_title,
                    'post_content' => $new_content,
                );
        
                $post_updated = wp_update_post($updated_post);
        
                if ($post_updated !== 0) {
                    // Update the featured image
                    if (!empty($new_featured_image['name'])) {
                        require_once ABSPATH . 'wp-admin/includes/image.php';
                        require_once ABSPATH . 'wp-admin/includes/file.php';
                        require_once ABSPATH . 'wp-admin/includes/media.php';
        
                        $attach_id = media_handle_upload('new_featured_image_' . $selected_post_id, $selected_post_id);
        
                        if (!is_wp_error($attach_id)) {
                            set_post_thumbnail($selected_post_id, $attach_id);
                        } else {
                            echo 'Error uploading the featured image. Please try again.';
                        }
                    }
        
                    // Update ACF field 'about' for the Trainer post
                    if ($new_about) {
                        update_field('about', $new_about, $selected_post_id);
                    }
                } else {
                    echo 'Failed to update the post with ID: ' . $selected_post_id . '<br>';
                }
            } else {
                echo 'Please provide both title and content for the post with ID: ' . $selected_post_id . '<br>';
            }
        endwhile;
    else :
        echo 'No Trainer posts found for the current user.';
    endif;

    wp_redirect(get_permalink()); // Redirect to the current page after updating all posts
    exit;
}
?>

<?php
get_footer();
?>
