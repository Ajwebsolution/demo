<?php
/**
 * Astra functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Define Constants
 */
define( 'ASTRA_THEME_VERSION', '4.5.1' );
define( 'ASTRA_THEME_SETTINGS', 'astra-settings' );
define( 'ASTRA_THEME_DIR', trailingslashit( get_template_directory() ) );
define( 'ASTRA_THEME_URI', trailingslashit( esc_url( get_template_directory_uri() ) ) );

/**
 * Minimum Version requirement of the Astra Pro addon.
 * This constant will be used to display the notice asking user to update the Astra addon to the version defined below.
 */
define( 'ASTRA_EXT_MIN_VER', '4.5.0' );

/**
 * Setup helper functions of Astra.
 */
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-theme-options.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-theme-strings.php';
require_once ASTRA_THEME_DIR . 'inc/core/common-functions.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-icons.php';

define( 'ASTRA_PRO_UPGRADE_URL', astra_get_pro_url( 'https://wpastra.com/pro/', 'dashboard', 'free-theme', 'upgrade-now' ) );
define( 'ASTRA_PRO_CUSTOMIZER_UPGRADE_URL', astra_get_pro_url( 'https://wpastra.com/pro/', 'customizer', 'free-theme', 'upgrade' ) );

/**
 * Update theme
 */
require_once ASTRA_THEME_DIR . 'inc/theme-update/astra-update-functions.php';
require_once ASTRA_THEME_DIR . 'inc/theme-update/class-astra-theme-background-updater.php';

/**
 * Fonts Files
 */
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-font-families.php';
if ( is_admin() ) {
	require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-fonts-data.php';
}

require_once ASTRA_THEME_DIR . 'inc/lib/webfont/class-astra-webfont-loader.php';
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-fonts.php';

require_once ASTRA_THEME_DIR . 'inc/dynamic-css/custom-menu-old-header.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/container-layouts.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/astra-icons.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-walker-page.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-enqueue-scripts.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-gutenberg-editor-css.php';
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-wp-editor-css.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/block-editor-compatibility.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/inline-on-mobile.php';
require_once ASTRA_THEME_DIR . 'inc/dynamic-css/content-background.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-dynamic-css.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-global-palette.php';

/**
 * Custom template tags for this theme.
 */
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-attr.php';
require_once ASTRA_THEME_DIR . 'inc/template-tags.php';

require_once ASTRA_THEME_DIR . 'inc/widgets.php';
require_once ASTRA_THEME_DIR . 'inc/core/theme-hooks.php';
require_once ASTRA_THEME_DIR . 'inc/admin-functions.php';
require_once ASTRA_THEME_DIR . 'inc/core/sidebar-manager.php';

/**
 * Markup Functions
 */
require_once ASTRA_THEME_DIR . 'inc/markup-extras.php';
require_once ASTRA_THEME_DIR . 'inc/extras.php';
require_once ASTRA_THEME_DIR . 'inc/blog/blog-config.php';
require_once ASTRA_THEME_DIR . 'inc/blog/blog.php';
require_once ASTRA_THEME_DIR . 'inc/blog/single-blog.php';

/**
 * Markup Files
 */
require_once ASTRA_THEME_DIR . 'inc/template-parts.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-loop.php';
require_once ASTRA_THEME_DIR . 'inc/class-astra-mobile-header.php';

/**
 * Functions and definitions.
 */
require_once ASTRA_THEME_DIR . 'inc/class-astra-after-setup-theme.php';

// Required files.
require_once ASTRA_THEME_DIR . 'inc/core/class-astra-admin-helper.php';

require_once ASTRA_THEME_DIR . 'inc/schema/class-astra-schema.php';

/* Setup API */
require_once ASTRA_THEME_DIR . 'admin/includes/class-astra-api-init.php';

if ( is_admin() ) {
	/**
	 * Admin Menu Settings
	 */
	require_once ASTRA_THEME_DIR . 'inc/core/class-astra-admin-settings.php';
	require_once ASTRA_THEME_DIR . 'admin/class-astra-admin-loader.php';
	require_once ASTRA_THEME_DIR . 'inc/lib/astra-notices/class-astra-notices.php';
}

/**
 * Metabox additions.
 */
require_once ASTRA_THEME_DIR . 'inc/metabox/class-astra-meta-boxes.php';

require_once ASTRA_THEME_DIR . 'inc/metabox/class-astra-meta-box-operations.php';

/**
 * Customizer additions.
 */
require_once ASTRA_THEME_DIR . 'inc/customizer/class-astra-customizer.php';

/**
 * Astra Modules.
 */
require_once ASTRA_THEME_DIR . 'inc/modules/posts-structures/class-astra-post-structures.php';
require_once ASTRA_THEME_DIR . 'inc/modules/related-posts/class-astra-related-posts.php';

/**
 * Compatibility
 */
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-gutenberg.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-jetpack.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/woocommerce/class-astra-woocommerce.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/edd/class-astra-edd.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/lifterlms/class-astra-lifterlms.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/learndash/class-astra-learndash.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-beaver-builder.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-bb-ultimate-addon.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-contact-form-7.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-visual-composer.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-site-origin.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-gravity-forms.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-bne-flyout.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-ubermeu.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-divi-builder.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-amp.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-yoast-seo.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-surecart.php';
require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-starter-content.php';
require_once ASTRA_THEME_DIR . 'inc/addons/transparent-header/class-astra-ext-transparent-header.php';
require_once ASTRA_THEME_DIR . 'inc/addons/breadcrumbs/class-astra-breadcrumbs.php';
require_once ASTRA_THEME_DIR . 'inc/addons/scroll-to-top/class-astra-scroll-to-top.php';
require_once ASTRA_THEME_DIR . 'inc/addons/heading-colors/class-astra-heading-colors.php';
require_once ASTRA_THEME_DIR . 'inc/builder/class-astra-builder-loader.php';

// Elementor Compatibility requires PHP 5.4 for namespaces.
if ( version_compare( PHP_VERSION, '5.4', '>=' ) ) {
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-elementor.php';
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-elementor-pro.php';
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-web-stories.php';
}

// Beaver Themer compatibility requires PHP 5.3 for anonymous functions.
if ( version_compare( PHP_VERSION, '5.3', '>=' ) ) {
	require_once ASTRA_THEME_DIR . 'inc/compatibility/class-astra-beaver-themer.php';
}

require_once ASTRA_THEME_DIR . 'inc/core/markup/class-astra-markup.php';

/**
 * Load deprecated functions
 */
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-filters.php';
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-hooks.php';
require_once ASTRA_THEME_DIR . 'inc/core/deprecated/deprecated-functions.php';

// Add HTML5 support
add_theme_support( 'html5', array(
	'search-form',
// 	'comment-list', 
// 	'comment-form',
	'gallery',
	'caption' ) );

// search form handle code


// AJAX handler for performing the search based on selected criteria
add_action('wp_ajax_perform_search', 'perform_search_callback');
add_action('wp_ajax_nopriv_perform_search', 'perform_search_callback');

function perform_search_callback() {
    global $wpdb;

    // Sanitize and retrieve posted data
    $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';
    $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
    $area = isset($_POST['area']) ? sanitize_text_field($_POST['area']) : '';

    // Table name
    $table_name = $wpdb->prefix . 'country';

    // Prepare the base SQL query
    $sql = "SELECT * FROM $table_name WHERE 1=1";

    // Add conditions based on user input
    if (!empty($country)) {
        $sql .= $wpdb->prepare(" AND country = %s", $country);
    }
    if (!empty($city)) {
        $sql .= $wpdb->prepare(" AND city = %s", $city);
    }
    if (!empty($area)) {
        $sql .= $wpdb->prepare(" AND area = %s", $area);
    }

    // Execute the query
    $results = $wpdb->get_results($sql, ARRAY_A);

    // Output the results or message
    if ($results) {
        foreach ($results as $result) {
            // Output the data as needed
            // echo 'ID: ' . $result['id'] . '<br>';
            echo 'Country: ' . $result['country'] . '<br>';
            echo 'City: ' . $result['city'] . '<br>';
            echo 'Area: ' . $result['area'] . '<br>';
			echo 'visatype: ' . $result['visatype'] . '<br>';
			// echo 'postalcode: ' . $result['postalcode'] . '<br>';
			// echo 'passport: ' . $result['passport'] . '<br>';
			// echo 'travelto: ' . $result['travelto'] . '<br>';
			// echo 'date: ' . $result['date'] . '<br>';
            
        }
    } else {
        echo 'No data found for the specified criteria.';
    }

    wp_die(); // Always end with wp_die() to complete the AJAX request
}

// AJAX handler for fetching countries from the database
add_action('wp_ajax_fetch_countries', 'fetch_countries_callback');
add_action('wp_ajax_nopriv_fetch_countries', 'fetch_countries_callback');

function fetch_countries_callback() {
    global $wpdb;

    // Table name
    $table_name = $wpdb->prefix . 'country'; // Update with your table name

    // Query to get distinct countries
    $countries = $wpdb->get_col("SELECT DISTINCT country FROM $table_name ORDER BY country");
	
	error_log(print_r($countries, true));

	if (!empty($countries)) {
        echo '<script>console.log('.json_encode($countries).');</script>';
    }

    $options = '<option value="">Select Country</option>';
    foreach ($countries as $country) {
        // Output options for country dropdown
        $options .= '<option value="' . esc_attr($country) . '">' . esc_html($country) . '</option>';
    }

    echo $options; // Output the populated options for countries
    wp_die(); // Always end with wp_die() to complete the AJAX request
}

// AJAX handler for fetching cities based on the selected country
add_action('wp_ajax_fetch_cities', 'fetch_cities_callback');
add_action('wp_ajax_nopriv_fetch_cities', 'fetch_cities_callback');

function fetch_cities_callback() {
    global $wpdb;

    // Retrieve the selected country from the AJAX request
    $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';

    // Table name
    $table_name = $wpdb->prefix . 'country'; // Update with your table name

    // Query to get distinct cities for the selected country
    $cities = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT city FROM $table_name WHERE country = %s ORDER BY city",
        $country
    ));

    $options = '<option value="">Select City</option>';
    foreach ($cities as $city) {
        // Output options for city dropdown
        $options .= '<option value="' . esc_attr($city) . '">' . esc_html($city) . '</option>';
    }

    echo $options; // Output the populated options for cities
    wp_die(); // Always end with wp_die() to complete the AJAX request
}
// AJAX handler for fetching visatypes from the database
add_action('wp_ajax_fetch_visatypes', 'fetch_visatypes_callback');
add_action('wp_ajax_nopriv_fetch_visatypes', 'fetch_visatypes_callback');

function fetch_visatypes_callback() {
    global $wpdb;

    // Retrieve the selected country and city from the AJAX request
    $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';
    $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';

    // Table name
    $table_name = $wpdb->prefix . 'country'; // Replace with your table name for visa types

    // Query to get distinct visa types for the selected country and city
    $visatypes = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT visatype FROM $table_name WHERE country = %s AND city = %s ORDER BY visatype",
        $country,
        $city
    ));

    $options = '<option value="">Select Visa Type</option>';

    foreach ($visatypes as $visatype) {
        // Output options for visa type dropdown
        $options .= '<option value="' . esc_attr($visatype) . '">' . esc_html($visatype) . '</option>';
    }

    echo str_replace('</option><option', '</option><br><option', $options); // Insert line breaks between options
    wp_die(); // Always end with wp_die() to complete the AJAX request
}





// AJAX handler for fetching areas based on the selected country and city
add_action('wp_ajax_fetch_areas', 'fetch_areas_callback');
add_action('wp_ajax_nopriv_fetch_areas', 'fetch_areas_callback');

function fetch_areas_callback() {
    global $wpdb;

    // Retrieve the selected country and city from the AJAX request
    $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';
    $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';

    // Table name
    $table_name = $wpdb->prefix . 'country'; // Update with your table name

    // Query to get distinct areas for the selected country and city
    $areas = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT area FROM $table_name WHERE country = %s AND city = %s ORDER BY area",
        $country,
        $city
    ));

    $options = '<option value="">Select Area</option>';
    foreach ($areas as $area) {
        // Output options for area dropdown
        $options .= '<option value="' . esc_attr($area) . '">' . esc_html($area) . '</option>';
    }

    echo $options; // Output the populated options for areas
    wp_die(); // Always end with wp_die() to complete the AJAX request
}

// Add a custom user role named "Trainer"
function create_trainer_role() {
    add_role(
        'trainer', // Role slug
        'Trainer', // Display name
        array(
            'read'         => true,  // Trainers can read posts
           
    
           
            // Add more capabilities as needed
        )
    );
}
add_action('init', 'create_trainer_role');
function add_trainer_capabilities() {
    $role = get_role('trainer');

    // Add capabilities to the 'trainer' role
    if ($role) {
        $role->add_cap('upload_files'); // Allow trainers to upload files
        $role->add_cap('edit_acf_fields'); // Replace 'edit_acf_fields' with the capability related to ACF fields
        // Add other capabilities related to ACF or media management
    }
}
add_action('init', 'add_trainer_capabilities');


function custom_hide_admin_bar() {
    // Get the current user
    $current_user = wp_get_current_user();

    // Check if the current user belongs to the 'trainer' role
    if (in_array('trainer', $current_user->roles)) {
        // Hide the admin bar for users with the 'trainer' role
        add_filter('show_admin_bar', '__return_false');
    }
}
add_action('init', 'custom_hide_admin_bar');




// Add AJAX action for fetching user and trainer details
add_action('wp_ajax_get_user_and_trainer_details', 'get_user_and_trainer_details_ajax');
add_action('wp_ajax_nopriv_get_user_and_trainer_details', 'get_user_and_trainer_details_ajax'); // Allow non-logged-in users to access

function get_user_and_trainer_details_ajax() {
    // Verify nonce for security (if used)
    // check_ajax_referer('my_nonce', 'security');

    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

    if ($user_id > 0) {
        // Get user details by ID
        $user = get_user_by('ID', $user_id);

        if ($user) {
            $user_display_name = $user->display_name;
            $user_email = $user->user_email ? $user->user_email : 'Email Not Available';

            // Get trainer data
            global $wpdb;
            $trainer_table = 'trainer'; // Replace with your table name without prefix

            $trainer_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$trainer_table} WHERE user_id = %d", $user_id));

            // Prepare user details HTML including trainer information
            $html = '<div class="user-details">';
            $html .= '<h2>' . esc_html($user_display_name) . '</h2>';
            $html .= '<p>Email: ' . esc_html($user_email) . '</p>';
               // Get profile image URL
    $current_user_profile_image = get_user_meta($user_id, 'profile_image', true);

    // Include profile image URL in the HTML response
    $html .= '<div class="profile-image">';
    $html .= '<img src="' . esc_url($current_user_profile_image) . '" alt="Profile Image">';
    $html .= '</div>';

            if ($trainer_data) {
                $html .= '<h3>Trainer Information</h3>';
                $html .= '<p>Date of Birth: ' . esc_html($trainer_data->dob) . '</p>';
                $html .= '<p>NAB: ' . esc_html($trainer_data->nab) . '</p>';
                $html .= '<p>Review: ' . esc_html($trainer_data->review) . '</p>';
                $html .= '<p>About: ' . esc_html($trainer_data->about) . '</p>';
                // Add more trainer information fields as needed
            }

            $html .= '</div>';

            // Return user and trainer details HTML
            wp_send_json_success($html);
        } else {
            wp_send_json_error('User not found.');
        }
    } else {
        wp_send_json_error('Invalid user ID.');
    }

    // Always exit to avoid extra output
    wp_die();
}
