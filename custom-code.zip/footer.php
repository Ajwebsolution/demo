<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Astra
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<?php astra_content_bottom(); ?>
	</div> <!-- ast-container -->
	</div><!-- #content -->
<?php 
	astra_content_after();
		
	astra_footer_before();
		
	astra_footer();
		
	astra_footer_after(); 
?>
	</div><!-- #page -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- <script>
jQuery(document).ready(function(){
    // Replace the text "5" with a star symbol (★)
    var starSymbol = '&#9733;'; // Unicode for star symbol
    jQuery('label[for="rating-5"]').html(starSymbol);
});
</script> -->
<?php 
  
	wp_footer(); 
?>
	</body>
</html>
