<?php
/*
 * Template Name: Custom Registration Template
 */

get_header();

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $userdata = array(
        'user_login'    => $username,
        'user_email'    => $email,
        'user_pass'     => $password,
        'role'          => 'trainer' // Set the role here (in this case, 'trainer')
    );

    $user_id = wp_insert_user($userdata);

    if (!is_wp_error($user_id)) {
        // Registration successful
        echo 'Registration successful! You can now <a href="' . wp_login_url() . '">login</a>.';

        // Insert data into the 'trainer' table
        global $wpdb;
        $trainer_table = 'trainer'; // Replace 'trainer' with your actual table name without prefix

        // Example: Inserting user ID into the 'trainer' table
        $trainer_data = array(
            'user_id' => $user_id,
            // Add more fields and values as needed
        );

        $inserted = $wpdb->insert($trainer_table, $trainer_data);

        if ($inserted) {
            echo 'User ID inserted into the trainer table.';
        } else {
            echo 'Failed to insert data into the trainer table.';
        }

        // Redirect to My Account page
        wp_redirect(home_url('/my-account')); // Change '/my-account' to your desired account page URL
        exit();
    } else {
        // Display error message
        echo 'Registration failed: ' . $user_id->get_error_message();
    }
} else {
    // Display registration form
    ?>
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <h1 class="entry-title">Register</h1>
                </header><!-- .entry-header -->

                <div class="entry-content">
                    <form id="registration-form" method="post" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>">
                        <p>
                            <label for="username">Username:</label>
                            <input type="text" name="username" required>
                        </p>
                        <p>
                            <label for="email">Email:</label>
                            <input type="email" name="email" required>
                        </p>
                        <p>
                            <label for="password">Password:</label>
                            <input type="password" name="password" required>
                        </p>
                        <p>
                            <input type="submit" name="register" value="Register">
                        </p>
                    </form>
                </div><!-- .entry-content -->
            </article><!-- #post-<?php the_ID(); ?> -->

        </main><!-- #main -->
    </div><!-- #primary -->
    <?php
}

get_footer();
