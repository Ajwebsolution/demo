<?php
/*
 * Template Name: Profile Dashboard
 */

get_header();

if (!is_user_logged_in()) {
    // Redirect non-logged-in users to the login page
    wp_redirect(wp_login_url());
    exit;
}

$current_user = wp_get_current_user();
$current_user_id = $current_user->ID;

// Get current user data from WordPress user meta
$current_user_display_name = $current_user->display_name;
$current_user_email = $current_user->user_email ? $current_user->user_email : 'Email Not Available';
$current_user_profile_image = get_user_meta($current_user_id, 'profile_image', true);
// Connect to the database
global $wpdb;

// WordPress Users Table
$user_table = $wpdb->users;
$user_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$user_table} WHERE ID = %d", $current_user_id));

// Custom Trainer Table
$trainer_table = 'trainer'; // Replace 'trainer' with your actual table name
$trainer_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$trainer_table} WHERE user_id = %d", $current_user_id));

// Get other users' data
$args = array(
    'exclude' => array($current_user_id), // Exclude the current user
    'fields' => 'all',
);

$other_users = get_users($args);
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title">Profile Dashboard</h1>
            </header><!-- .entry-header -->

            <div class="entry-content">
                <div class="user-profile-container">
                    <!-- Display current user information -->
                    <div class="profile-info">
                        <?php if ($current_user_profile_image) : ?>
                            <!-- Display profile image on the left -->
                            <div class="profile-image">
                                <img src="<?php echo esc_url($current_user_profile_image); ?>" alt="Profile Image">
                            </div>
                        <?php endif; ?>

                        <!-- Display user information on the right -->
                        <div class="profile-details">
                            <h2><?php echo esc_html($current_user_display_name); ?></h2>
                            <p>Email: <?php echo esc_html($current_user_email); ?></p>
                            <!-- Display user-related data -->
                            <?php if ($user_data) : ?>
                                <h3>User Information:</h3>
                                <p>User ID: <?php echo esc_html($user_data->ID); ?></p>
                                <p>Username: <?php echo esc_html($user_data->user_login); ?></p>
                                <!-- Add more fields as needed -->
                            <?php endif; ?>

                            <!-- Display trainer-related data -->
                            <?php if ($trainer_data) : ?>
                                <h3>Trainer Information:</h3>
                                <p>Trainer ID: <?php echo esc_html($trainer_data->user_id); ?></p>
                                <p>NAB: <?php echo esc_html($trainer_data->nab); ?></p>
                                <p>DOB: <?php echo esc_html($trainer_data->dob); ?></p>
                                <p>Review: <?php echo esc_html($trainer_data->review); ?></p>
                                <p>About: <?php echo esc_html($trainer_data->about); ?></p>
                                <!-- Add more fields as needed -->
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Dropdown list of other users -->
                    <div class="other-users-dropdown">
                        <h3>Select User:</h3>
                        <select id="other-users-list">
                            <option value="">Select a user</option>
                            <?php foreach ($other_users as $user) : ?>
                                <option value="<?php echo esc_attr($user->ID); ?>"><?php echo esc_html($user->display_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Display detailed information of selected user -->
                    <div class="selected-user-details" id="selected-user-details">
                        <h3>User Details</h3>
                        <!-- Display selected user information here using JavaScript -->
                    </div>
                </div>
            </div><!-- .entry-content -->
        </article><!-- #post-<?php the_ID(); ?> -->

    </main><!-- #main -->
</div><!-- #primary -->
<?php
if (is_user_logged_in()) {
    $user_id = get_current_user_id();
    $gallery_images = get_field('trainer_image_gallery', 'user_' . $user_id);

    if ($gallery_images) {
        foreach ($gallery_images as $image_item) {
            $image_url = $image_item['t_image_gallery']['url'];
            $image_alt = $image_item['t_image_gallery']['alt'];

            ?>
            <div class="current-user-gallery">
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
            </div>
            <?php
        }
    } else {
        echo 'No images found.';
    }
} else {
    echo 'Please log in to view the images.';
}
?>

<script>
 document.getElementById('other-users-list').addEventListener('change', function() {
    var selectedUserId = this.value;

    if (selectedUserId) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        document.getElementById('selected-user-details').innerHTML = response.data;
                    } else {
                        console.error('Error: ' + response.data);
                    }
                } else {
                    console.error('Error occurred while fetching user details.');
                }
            }
        };

        xhr.open('GET', '<?php echo esc_url(admin_url('admin-ajax.php')); ?>?action=get_user_and_trainer_details&user_id=' + selectedUserId, true);
        xhr.send();
    } else {
        document.getElementById('selected-user-details').innerHTML = '<h3>User Details</h3>';
    }
});


</script>

<?php get_footer(); ?>
