<?php
/*
 * Template Name: Edit Profile
 */

get_header();

if (!is_user_logged_in()) {
    // Redirect non-logged-in users to the login page
    wp_redirect(wp_login_url());
    exit;
}

$current_user = wp_get_current_user();
$current_user_id = $current_user->ID;

// Get user data
$current_user_display_name = $current_user->display_name;
$current_user_email = $current_user->user_email ? $current_user->user_email : 'Email Not Available';
$current_user_profile_image = get_user_meta($current_user_id, 'profile_image', true);

// Get trainer data
global $wpdb;
$trainer_table = 'trainer'; // Replace with your table name without prefix

$trainer_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$trainer_table} WHERE user_id = %d", $current_user_id));

?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title">Edit Your Profile </h1>
            </header><!-- .entry-header -->

            <div class="entry-content">
                <div class="user-profile-container">
                    <div class="profile-info">
                        <?php if ($current_user_profile_image) : ?>
                            <!-- Display profile image on the left -->
                            <div class="profile-image">
                                <img src="<?php echo esc_url($current_user_profile_image); ?>" alt="Profile Image">
                            </div>
                        <?php endif; ?>

                        <!-- Display user information on the right -->
                        <div class="profile-details">
                            <h2><?php echo esc_html($current_user_display_name); ?></h2>
                            <p>Email: <?php echo esc_html($current_user_email); ?></p>
                            <!-- Add more user information fields as needed -->
                            <!-- Example: <p>Biography: <?php echo esc_html(get_user_meta($current_user_id, 'biography', true)); ?></p> -->
                        </div>
                    </div>

                    <div class="edit-profile">
                        <h3>Edit Profile</h3>
                        <form id="user-info-form" method="post" enctype="multipart/form-data">
                            <p>
                                <label for="user_email">Email:</label>
                                <input type="email" name="user_email" value="<?php echo esc_attr($current_user_email); ?>">
                            </p>
                            <p>
                                <label for="display_name">Full Name:</label>
                                <input type="text" name="display_name" value="<?php echo esc_attr($current_user_display_name); ?>">
                            </p>
                            <p>
                                <label for="profile_image">Profile Image:</label>
                                <input type="file" name="profile_image">
                            </p>
                            <p>
                                <label for="dob">Date of Birth:</label>
                                <input type="date" name="dob" value="<?php echo isset($trainer_data->dob) ? esc_attr($trainer_data->dob) : ''; ?>">
                            </p>
                            <p>
                                <label for="nab">NAB:</label>
                                <input type="text" name="nab" value="<?php echo isset($trainer_data->nab) ? esc_attr($trainer_data->nab) : ''; ?>">
                            </p>
                            <p>
                                <label for="review">Review:</label>
                                <textarea name="review" rows="4"><?php echo isset($trainer_data->review) ? esc_textarea($trainer_data->review) : ''; ?></textarea>
                            </p>
                            <p>
                                <label for="about">About:</label>
                                <textarea name="about" rows="4"><?php echo isset($trainer_data->about) ? esc_textarea($trainer_data->about) : ''; ?></textarea>
                            </p>

                            <p>
                                <input type="submit" name="update_user_info" value="Update Information">
                            </p>
                        </form>
                    </div>
                </div>
            </div><!-- .entry-content -->
        </article><!-- #post-<?php the_ID();
        
       
        
        ?> -->
<?php comments_template();?>
    </main><!-- #main -->
</div><!-- #primary -->
<?php comments_template();?>
<section>
    <div class="image_gallery">
        <?php
    $current_user = wp_get_current_user();
$current_user_id = $current_user->ID;

acf_form_head(); // Include ACF form scripts and styles

acf_form(array(
    'post_id'       => 'user_' . $current_user_id,
    'field_groups'  => array('group_6572ba0cb4f29'), // Replace with the actual field group ID containing the Repeater field
    'submit_value'  => 'Update Gallery', // Label for the submit button
    'updated_message' => 'Gallery Updated Successfully', // Confirmation message after updating the gallery
    'fields'        => array('trainer_image_gallery'), // Replace with the name of your ACF Repeater field
    'html_submit_button' => '<input type="submit" class="acf-button button button-primary button-large" value="%s" />', // Custom submit button HTML
    'return' => add_query_arg('updated', 'true', get_permalink()), // Redirect URL after form submission
));
?>
    </div>
</section>
<?php
get_footer();

// Process form submission to update user information if the form is submitted
if (isset($_POST['update_user_info'])) {
    // Retrieve and sanitize form data
    $updated_user_email = sanitize_email($_POST['user_email']);
    $updated_display_name = sanitize_text_field($_POST['display_name']);
    $dob = sanitize_text_field($_POST['dob']);
    $nab = sanitize_text_field($_POST['nab']);
    $review = sanitize_textarea_field($_POST['review']);
    $about = sanitize_textarea_field($_POST['about']);

    // Update user email and display name
    $user_update_args = array(
        'ID' => $current_user_id,
        'user_email' => $updated_user_email,
        'display_name' => $updated_display_name,
    );

    $user_updated = wp_update_user($user_update_args);

    // Check if user update was successful
    if (!is_wp_error($user_updated)) {
        // Handle profile image upload
        if (!empty($_FILES['profile_image']['name'])) {
            $profile_image = $_FILES['profile_image'];

            // Upload profile image
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($profile_image, $upload_overrides);

            if ($movefile && !isset($movefile['error'])) {
                $image_url = $movefile['url'];

                // Update user meta with the uploaded image URL
                update_user_meta($current_user_id, 'profile_image', $image_url);
            }
        }

        // Insert or update data in the 'trainer' table
        if ($trainer_data) {
            // If data exists, update it
            $updated = $wpdb->update(
                $trainer_table,
                array(
                    'dob' => $dob,
                    'nab' => $nab,
                    'review' => $review,
                    'about' => $about,
                ),
                array('user_id' => $current_user_id),
                array('%s', '%s', '%s', '%s'),
                array('%d')
            );

            if ($updated !== false) {
                echo 'Trainer information updated successfully.';
            } else {
                echo 'Failed to update trainer information.';
            }
        } else {
            // If no data exists, insert it
            $inserted = $wpdb->insert(
                $trainer_table,
                array(
                    'user_id' => $current_user_id,
                    'dob' => $dob,
                    'nab' => $nab,
                    'review' => $review,
                    'about' => $about,
                ),
                array('%d', '%s', '%s', '%s', '%s')
            );

            if ($inserted) {
                echo 'Trainer information inserted successfully.';
            } else {
                echo 'Failed to insert trainer information.';
            }
        }
    } else {
        echo 'Failed to update user information: ' . $user_updated->get_error_message();
    }
}
?>