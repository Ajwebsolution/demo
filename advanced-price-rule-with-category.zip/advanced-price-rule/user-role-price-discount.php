<?php
/*
Plugin Name: User Role Price Discount
Description: Apply different price discounts based on user roles for selected product categories and display the discounted price.
Version: 1.0
Author: Your Name
*/

// Add settings page to set role-based discounts for selected categories
function role_based_discount_settings() {
    add_menu_page(
        'Role-based Discounts',
        'Role Discounts',
        'manage_options',
        'role_discount_settings',
        'role_discount_settings_page'
    );
}
add_action('admin_menu', 'role_based_discount_settings');

// Display settings page content
function role_discount_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $user_roles = wp_roles()->roles;
    $role_discounts = get_option('role_based_discounts', array());

    if (isset($_POST['submit'])) {
        $submitted_discounts = isset($_POST['role_discount']) ? $_POST['role_discount'] : array();

        foreach ($user_roles as $role => $details) {
            if (isset($submitted_discounts[$role])) {
                $role_discounts[$role] = isset($role_discounts[$role]) ? $role_discounts[$role] : array();
                $role_discounts[$role] = $submitted_discounts[$role]; // Replace the entire array
            }
        }

        update_option('role_based_discounts', $role_discounts);
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    $product_categories = get_terms('product_cat', array('hide_empty' => false));
    ?>
    <div class="wrap">
        <h1>Role-based Discounts</h1>
        <form method="post">
            <?php foreach ($product_categories as $category) { ?>
                <h2><?php echo esc_html($category->name); ?> Discount</h2>
                <?php foreach ($user_roles as $role => $details) { ?>
                    <label for="role_discount_<?php echo esc_attr($role); ?>_<?php echo esc_attr($category->term_id); ?>">
                        <input type="number" name="role_discount[<?php echo esc_attr($role); ?>][<?php echo esc_attr($category->term_id); ?>]" id="role_discount_<?php echo esc_attr($role); ?>_<?php echo esc_attr($category->term_id); ?>" value="<?php echo esc_attr(isset($role_discounts[$role][$category->term_id]) ? $role_discounts[$role][$category->term_id] : 0); ?>" /> <?php echo esc_html($details['name']); ?> Discount for <?php echo esc_html($category->name); ?>
                    </label>
                    <br>
                <?php } ?>
            <?php } ?>
            <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>
        </form>
    </div>
    <?php
}

// Apply role-based discounts for selected categories
function apply_role_based_discount($price, $product) {
    $user = wp_get_current_user();

    if (is_user_logged_in() && !empty($user->roles)) {
        $user_role = $user->roles[0];
        $role_discounts = get_option('role_based_discounts', array());
        $product_categories = get_the_terms($product->get_id(), 'product_cat');

        if ($product_categories) {
            foreach ($product_categories as $product_category) {
                $category_id = $product_category->term_id;
                if (isset($role_discounts[$user_role][$category_id])) {
                    $discount_percentage = $role_discounts[$user_role][$category_id];
                    $discount = $product->get_price() * ($discount_percentage / 100);
                    $discounted_price = $product->get_price() - $discount;

                    // Return the discounted price instead of the original price
                    return wc_price($discounted_price);
                }
            }
        }
    }

    return $price;
}

// Hook into the WooCommerce price display for selected categories
add_filter('woocommerce_get_price_html', 'apply_role_based_discount', 10, 2);
